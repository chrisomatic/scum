#!/bin/sh
./bin/scum
